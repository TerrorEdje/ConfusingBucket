@extends('layout.main')

@section('content')
	<p>hee hallow</p>
@stop