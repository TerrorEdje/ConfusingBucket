@extends('layout.main')

@section('content')
	<h1>Dit is jou test pagina</h1>
	<p>Hier zul je alle test bestanden vinden en een helehoop meer rommel die eigenlijk nergens over gaat.</p>
	<a href="{{ URL::route('test') }}">Naar test</a>
@stop