@extends('layout.main')

@section('content')	
	De story is geupload.</br>
	
@stop