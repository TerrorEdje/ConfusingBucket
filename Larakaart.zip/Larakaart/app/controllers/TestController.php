<?php

class TestController extends BaseController {

	public function test1()
	{
		$user = User::find(1);
		//echo $user->username.' = gebruikersnaam.';
		return View::make('test');
	}

}